import { Server } from 'socket.io';

interface UserSocket {
  userId: string;
  socketId: string;
}

interface RealTimeEvent {
  type: 'schedule_update' | 'goal_update' | 'chat_message' | 'team_invite';
  data: any;
  userId: string;
  timestamp: Date;
}

// Store connected users
const connectedUsers = new Map<string, UserSocket>();

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Handle user authentication
    socket.on('authenticate', (userData: { userId: string; token: string }) => {
      // In a real app, validate the token here
      const { userId } = userData;
      
      // Store user connection
      connectedUsers.set(socket.id, { userId, socketId: socket.id });
      
      // Join user-specific room
      socket.join(`user:${userId}`);
      
      // Join user's teams rooms
      socket.join(`teams:${userId}`);
      
      console.log(`User ${userId} authenticated with socket ${socket.id}`);
      
      socket.emit('authenticated', { success: true, userId });
    });

    // Handle schedule updates
    socket.on('schedule_update', (data: { scheduleId: string; update: any }) => {
      const userSocket = connectedUsers.get(socket.id);
      if (!userSocket) return;
      
      const event: RealTimeEvent = {
        type: 'schedule_update',
        data: { scheduleId: data.scheduleId, update: data.update },
        userId: userSocket.userId,
        timestamp: new Date()
      };
      
      // Broadcast to user's rooms
      io.to(`user:${userSocket.userId}`).emit('realtime_event', event);
    });

    // Handle goal updates
    socket.on('goal_update', (data: { goalId: string; update: any }) => {
      const userSocket = connectedUsers.get(socket.id);
      if (!userSocket) return;
      
      const event: RealTimeEvent = {
        type: 'goal_update',
        data: { goalId: data.goalId, update: data.update },
        userId: userSocket.userId,
        timestamp: new Date()
      };
      
      // Broadcast to user's rooms
      io.to(`user:${userSocket.userId}`).emit('realtime_event', event);
    });

    // Handle chat messages
    socket.on('chat_message', (data: { threadId: string; message: string }) => {
      const userSocket = connectedUsers.get(socket.id);
      if (!userSocket) return;
      
      const event: RealTimeEvent = {
        type: 'chat_message',
        data: { threadId: data.threadId, message: data.message, senderId: userSocket.userId },
        userId: userSocket.userId,
        timestamp: new Date()
      };
      
      // Broadcast to user's rooms
      io.to(`user:${userSocket.userId}`).emit('realtime_event', event);
    });

    // Handle team invitations
    socket.on('team_invite', (data: { teamId: string; inviteeId: string; inviterId: string }) => {
      const userSocket = connectedUsers.get(socket.id);
      if (!userSocket) return;
      
      const event: RealTimeEvent = {
        type: 'team_invite',
        data: { teamId: data.teamId, inviteeId: data.inviteeId, inviterId: data.inviterId },
        userId: userSocket.userId,
        timestamp: new Date()
      };
      
      // Send to specific user
      io.to(`user:${data.inviteeId}`).emit('realtime_event', event);
    });

    // Handle typing indicators
    socket.on('typing_start', (data: { threadId: string }) => {
      const userSocket = connectedUsers.get(socket.id);
      if (!userSocket) return;
      
      socket.to(`thread:${data.threadId}`).emit('user_typing', {
        userId: userSocket.userId,
        threadId: data.threadId,
        isTyping: true
      });
    });

    socket.on('typing_stop', (data: { threadId: string }) => {
      const userSocket = connectedUsers.get(socket.id);
      if (!userSocket) return;
      
      socket.to(`thread:${data.threadId}`).emit('user_typing', {
        userId: userSocket.userId,
        threadId: data.threadId,
        isTyping: false
      });
    });

    // Handle joining chat threads
    socket.on('join_thread', (threadId: string) => {
      const userSocket = connectedUsers.get(socket.id);
      if (!userSocket) return;
      
      socket.join(`thread:${threadId}`);
      console.log(`User ${userSocket.userId} joined thread ${threadId}`);
    });

    // Handle leaving chat threads
    socket.on('leave_thread', (threadId: string) => {
      socket.leave(`thread:${threadId}`);
      console.log(`User left thread ${threadId}`);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      
      // Remove from connected users
      connectedUsers.delete(socket.id);
    });

    // Send welcome message
    socket.emit('message', {
      text: 'Welcome to Nexus Real-time Server!',
      senderId: 'system',
      timestamp: new Date().toISOString(),
    });
  });
};

// Helper functions for broadcasting events
export const broadcastToUser = (io: Server, userId: string, event: RealTimeEvent) => {
  io.to(`user:${userId}`).emit('realtime_event', event);
};

export const broadcastToTeam = (io: Server, teamId: string, event: RealTimeEvent) => {
  io.to(`team:${teamId}`).emit('realtime_event', event);
};

export const broadcastToThread = (io: Server, threadId: string, event: RealTimeEvent) => {
  io.to(`thread:${threadId}`).emit('realtime_event', event);
};

// Get connected users count
export const getConnectedUsersCount = () => {
  return connectedUsers.size;
};

// Check if user is connected
export const isUserConnected = (userId: string) => {
  for (const [socketId, userSocket] of connectedUsers) {
    if (userSocket.userId === userId) {
      return true;
    }
  }
  return false;
};