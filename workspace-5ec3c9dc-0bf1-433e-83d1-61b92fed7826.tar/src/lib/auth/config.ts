import { NextAuthOptions } from 'next-auth'
import { PrismaAdapter } from '@next-auth/prisma-adapter'
import { db } from '@/lib/db'
import GoogleProvider from 'next-auth/providers/google'

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(db),
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      authorization: {
        params: {
          prompt: "consent",
          access_type: "offline",
          response_type: "code",
          scope: "openid email profile https://www.googleapis.com/auth/calendar"
        }
      }
    })
  ],
  session: {
    strategy: 'jwt'
  },
  callbacks: {
    async jwt({ token, account, user }) {
      if (account) {
        token.accessToken = account.access_token
        token.refreshToken = account.refresh_token
      }
      if (user) {
        token.userId = user.id
      }
      return token
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken as string
      session.refreshToken = token.refreshToken as string
      session.userId = token.userId as string
      
      // Get user from database
      if (session.userId) {
        const dbUser = await db.user.findUnique({
          where: { id: session.userId },
          select: {
            id: true,
            email: true,
            name: true,
            avatar: true,
            timezone: true,
            subscriptionTier: true,
            lifetimeAccess: true,
            googleCalendarToken: true,
            googleCalendarRefreshToken: true,
            googleCalendarId: true
          }
        })
        
        if (dbUser) {
          session.user = {
            id: dbUser.id,
            email: dbUser.email,
            name: dbUser.name,
            image: dbUser.avatar
          }
          
          // Add custom properties
          (session as any).user.timezone = dbUser.timezone
          (session as any).user.subscriptionTier = dbUser.subscriptionTier
          (session as any).user.lifetimeAccess = dbUser.lifetimeAccess
          (session as any).user.googleCalendarConnected = !!dbUser.googleCalendarToken
        }
      }
      
      return session
    },
    async signIn({ user, account, profile }) {
      try {
        if (account?.provider === 'google' && profile) {
          // Check if user exists
          let dbUser = await db.user.findUnique({
            where: { email: profile.email! }
          })

          if (!dbUser) {
            // Create new user
            dbUser = await db.user.create({
              data: {
                email: profile.email!,
                name: profile.name || profile.email!.split('@')[0],
                avatar: profile.image,
                timezone: TimeZoneService.detectUserTimeZone(),
                googleCalendarToken: account.access_token,
                googleCalendarRefreshToken: account.refresh_token,
                googleCalendarId: profile.email
              }
            })
          } else {
            // Update existing user with Google Calendar tokens
            dbUser = await db.user.update({
              where: { id: dbUser.id },
              data: {
                googleCalendarToken: account.access_token,
                googleCalendarRefreshToken: account.refresh_token,
                googleCalendarId: profile.email
              }
            })
          }

          // Set user ID for the session
          user.id = dbUser.id
        }
        
        return true
      } catch (error) {
        console.error('Error in signIn callback:', error)
        return false
      }
    }
  },
  pages: {
    signIn: '/auth/signin',
    signOut: '/auth/signout',
    error: '/auth/error'
  }
}

import { TimeZoneService } from '@/lib/services/timezone'