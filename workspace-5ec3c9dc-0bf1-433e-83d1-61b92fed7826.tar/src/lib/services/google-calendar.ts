import { google } from 'googleapis'

export interface GoogleCalendarEvent {
  id: string
  summary: string
  description?: string
  start: {
    dateTime?: string
    date?: string
    timeZone?: string
  }
  end: {
    dateTime?: string
    date?: string
    timeZone?: string
  }
  location?: string
  status: string
  created: string
  updated: string
}

export class GoogleCalendarService {
  private oauth2Client: any

  constructor(accessToken: string) {
    this.oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET
    )
    this.oauth2Client.setCredentials({
      access_token: accessToken
    })
  }

  async listEvents(
    calendarId: string = 'primary',
    timeMin: Date,
    timeMax: Date
  ): Promise<GoogleCalendarEvent[]> {
    try {
      const calendar = google.calendar({ version: 'v3', auth: this.oauth2Client })
      
      const response = await calendar.events.list({
        calendarId,
        timeMin: timeMin.toISOString(),
        timeMax: timeMax.toISOString(),
        singleEvents: true,
        orderBy: 'startTime'
      })

      return response.data.items || []
    } catch (error) {
      console.error('Error fetching Google Calendar events:', error)
      throw error
    }
  }

  async createEvent(
    event: {
      summary: string
      description?: string
      start: Date
      end: Date
      location?: string
      timeZone?: string
    },
    calendarId: string = 'primary'
  ): Promise<GoogleCalendarEvent> {
    try {
      const calendar = google.calendar({ version: 'v3', auth: this.oauth2Client })
      
      const event_data = {
        summary: event.summary,
        description: event.description,
        start: {
          dateTime: event.start.toISOString(),
          timeZone: event.timeZone || 'UTC'
        },
        end: {
          dateTime: event.end.toISOString(),
          timeZone: event.timeZone || 'UTC'
        },
        location: event.location
      }

      const response = await calendar.events.insert({
        calendarId,
        requestBody: event_data
      })

      return response.data
    } catch (error) {
      console.error('Error creating Google Calendar event:', error)
      throw error
    }
  }

  async updateEvent(
    eventId: string,
    event: {
      summary?: string
      description?: string
      start?: Date
      end?: Date
      location?: string
      timeZone?: string
    },
    calendarId: string = 'primary'
  ): Promise<GoogleCalendarEvent> {
    try {
      const calendar = google.calendar({ version: 'v3', auth: this.oauth2Client })
      
      const event_data: any = {}
      if (event.summary) event_data.summary = event.summary
      if (event.description) event_data.description = event.description
      if (event.location) event_data.location = event.location
      
      if (event.start) {
        event_data.start = {
          dateTime: event.start.toISOString(),
          timeZone: event.timeZone || 'UTC'
        }
      }
      
      if (event.end) {
        event_data.end = {
          dateTime: event.end.toISOString(),
          timeZone: event.timeZone || 'UTC'
        }
      }

      const response = await calendar.events.update({
        calendarId,
        eventId,
        requestBody: event_data
      })

      return response.data
    } catch (error) {
      console.error('Error updating Google Calendar event:', error)
      throw error
    }
  }

  async deleteEvent(
    eventId: string,
    calendarId: string = 'primary'
  ): Promise<void> {
    try {
      const calendar = google.calendar({ version: 'v3', auth: this.oauth2Client })
      
      await calendar.events.delete({
        calendarId,
        eventId
      })
    } catch (error) {
      console.error('Error deleting Google Calendar event:', error)
      throw error
    }
  }

  async syncEvents(
    nexusEvents: Array<{
      id: string
      title: string
      description?: string
      startTime: Date
      endTime: Date
      location?: string
      googleCalendarEventId?: string
    }>,
    calendarId: string = 'primary'
  ): Promise<Array<{
    nexusEventId: string
    googleEventId: string
    action: 'created' | 'updated' | 'skipped'
  }>> {
    const results = []

    try {
      // Get existing Google Calendar events
      const timeMin = new Date(Math.min(...nexusEvents.map(e => e.startTime.getTime())))
      const timeMax = new Date(Math.max(...nexusEvents.map(e => e.endTime.getTime())))
      
      const googleEvents = await this.listEvents(calendarId, timeMin, timeMax)

      // Create a map of Google events by ID for quick lookup
      const googleEventsMap = new Map<string, GoogleCalendarEvent>()
      googleEvents.forEach(event => {
        if (event.id) {
          googleEventsMap.set(event.id, event)
        }
      })

      // Process each Nexus event
      for (const nexusEvent of nexusEvents) {
        try {
          if (nexusEvent.googleCalendarEventId) {
            // Check if the Google event still exists
            const googleEvent = googleEventsMap.get(nexusEvent.googleCalendarEventId)
            
            if (googleEvent) {
              // Update the existing event
              await this.updateEvent(nexusEvent.googleCalendarEventId, {
                summary: nexusEvent.title,
                description: nexusEvent.description,
                start: nexusEvent.startTime,
                end: nexusEvent.endTime,
                location: nexusEvent.location
              }, calendarId)
              
              results.push({
                nexusEventId: nexusEvent.id,
                googleEventId: nexusEvent.googleCalendarEventId,
                action: 'updated'
              })
            } else {
              // Event doesn't exist in Google Calendar, create it
              const newGoogleEvent = await this.createEvent({
                summary: nexusEvent.title,
                description: nexusEvent.description,
                start: nexusEvent.startTime,
                end: nexusEvent.endTime,
                location: nexusEvent.location
              }, calendarId)
              
              results.push({
                nexusEventId: nexusEvent.id,
                googleEventId: newGoogleEvent.id || '',
                action: 'created'
              })
            }
          } else {
            // No Google Calendar event ID, create new event
            const newGoogleEvent = await this.createEvent({
              summary: nexusEvent.title,
              description: nexusEvent.description,
              start: nexusEvent.startTime,
              end: nexusEvent.endTime,
              location: nexusEvent.location
            }, calendarId)
            
            results.push({
              nexusEventId: nexusEvent.id,
              googleEventId: newGoogleEvent.id || '',
              action: 'created'
            })
          }
        } catch (error) {
          console.error(`Error syncing event ${nexusEvent.id}:`, error)
          results.push({
            nexusEventId: nexusEvent.id,
            googleEventId: '',
            action: 'skipped'
          })
        }
      }

      return results
    } catch (error) {
      console.error('Error syncing events to Google Calendar:', error)
      throw error
    }
  }
}