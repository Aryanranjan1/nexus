export interface TimeZoneInfo {
  id: string
  name: string
  offset: string
  currentTime: Date
}

export interface ConvertedTime {
  originalTime: Date
  originalTimeZone: string
  convertedTime: Date
  targetTimeZone: string
  formattedOriginal: string
  formattedConverted: string
}

export class TimeZoneService {
  private static readonly COMMON_TIME_ZONES = [
    { id: 'UTC', name: 'Coordinated Universal Time' },
    { id: 'America/New_York', name: 'Eastern Time' },
    { id: 'America/Chicago', name: 'Central Time' },
    { id: 'America/Denver', name: 'Mountain Time' },
    { id: 'America/Los_Angeles', name: 'Pacific Time' },
    { id: 'Europe/London', name: 'Greenwich Mean Time' },
    { id: 'Europe/Paris', name: 'Central European Time' },
    { id: 'Asia/Tokyo', name: 'Japan Standard Time' },
    { id: 'Asia/Shanghai', name: 'China Standard Time' },
    { id: 'Asia/Singapore', name: 'Singapore Time' },
    { id: 'Asia/Kolkata', name: 'India Standard Time' },
    { id: 'Australia/Sydney', name: 'Australian Eastern Time' }
  ]

  static getCommonTimeZones(): TimeZoneInfo[] {
    return this.COMMON_TIME_ZONES.map(tz => ({
      id: tz.id,
      name: tz.name,
      offset: this.getTimeZoneOffset(tz.id),
      currentTime: this.getCurrentTimeInTimeZone(tz.id)
    }))
  }

  static getCurrentTimeInTimeZone(timeZone: string): Date {
    const now = new Date()
    const timeString = now.toLocaleString('en-US', { timeZone })
    return new Date(timeString)
  }

  static getTimeZoneOffset(timeZone: string): string {
    const now = new Date()
    const utcDate = new Date(now.getTime() + now.getTimezoneOffset() * 60000)
    const tzDate = new Date(utcDate.toLocaleString('en-US', { timeZone }))
    const offset = (tzDate.getTime() - utcDate.getTime()) / (1000 * 60 * 60)
    
    const sign = offset >= 0 ? '+' : '-'
    const absOffset = Math.abs(offset)
    const hours = Math.floor(absOffset)
    const minutes = Math.round((absOffset - hours) * 60)
    
    return `UTC${sign}${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`
  }

  static convertTime(
    time: Date,
    fromTimeZone: string,
    toTimeZone: string
  ): ConvertedTime {
    const formattedOriginal = this.formatDateTimeInTimeZone(time, fromTimeZone)
    
    // Create a new date object in the target timezone
    const timeString = time.toLocaleString('en-US', { timeZone: fromTimeZone })
    const convertedTime = new Date(timeString)
    const formattedConverted = this.formatDateTimeInTimeZone(convertedTime, toTimeZone)
    
    return {
      originalTime: time,
      originalTimeZone: fromTimeZone,
      convertedTime,
      targetTimeZone: toTimeZone,
      formattedOriginal,
      formattedConverted
    }
  }

  static formatDateTimeInTimeZone(date: Date, timeZone: string): string {
    return date.toLocaleString('en-US', {
      timeZone,
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    })
  }

  static formatDateInTimeZone(date: Date, timeZone: string): string {
    return date.toLocaleDateString('en-US', {
      timeZone,
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      weekday: 'short'
    })
  }

  static formatTimeInTimeZone(date: Date, timeZone: string): string {
    return date.toLocaleTimeString('en-US', {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    })
  }

  static isWorkingHours(date: Date, timeZone: string, workingHours: { start: string; end: string }): boolean {
    const localDate = new Date(date.toLocaleString('en-US', { timeZone }))
    const hours = localDate.getHours()
    const minutes = localDate.getMinutes()
    
    const [startHour, startMinute] = workingHours.start.split(':').map(Number)
    const [endHour, endMinute] = workingHours.end.split(':').map(Number)
    
    const totalMinutes = hours * 60 + minutes
    const startTotalMinutes = startHour * 60 + startMinute
    const endTotalMinutes = endHour * 60 + endMinute
    
    return totalMinutes >= startTotalMinutes && totalMinutes <= endTotalMinutes
  }

  static getWorkingHoursForDate(date: Date, timeZone: string): { start: Date; end: Date } {
    const localDate = new Date(date.toLocaleString('en-US', { timeZone }))
    
    const start = new Date(localDate)
    start.setHours(9, 0, 0, 0) // 9:00 AM
    
    const end = new Date(localDate)
    end.setHours(17, 0, 0, 0) // 5:00 PM
    
    return { start, end }
  }

  static getTimeDifference(timeZone1: string, timeZone2: string): number {
    const now = new Date()
    const time1 = this.getCurrentTimeInTimeZone(timeZone1)
    const time2 = this.getCurrentTimeInTimeZone(timeZone2)
    
    return (time2.getTime() - time1.getTime()) / (1000 * 60 * 60) // Difference in hours
  }

  static findBestMeetingTime(
    participants: Array<{ timeZone: string; workingHours?: { start: string; end: string } }>,
    duration: number, // in minutes
    dateRange: { start: Date; end: Date }
  ): Array<{ start: Date; end: Date; confidence: number }> {
    const availableSlots: Array<{ start: Date; end: Date; confidence: number }> = []
    
    // Check each day in the date range
    for (let date = new Date(dateRange.start); date <= dateRange.end; date.setDate(date.getDate() + 1)) {
      const daySlots = this.getAvailableSlotsForDay(date, participants, duration)
      availableSlots.push(...daySlots)
    }
    
    // Sort by confidence (number of participants available)
    return availableSlots.sort((a, b) => b.confidence - a.confidence)
  }

  private static getAvailableSlotsForDay(
    date: Date,
    participants: Array<{ timeZone: string; workingHours?: { start: string; end: string } }>,
    duration: number
  ): Array<{ start: Date; end: Date; confidence: number }> {
    const slots: Array<{ start: Date; end: Date; confidence: number }> = []
    
    // Default working hours if not specified
    const defaultWorkingHours = { start: '09:00', end: '17:00' }
    
    // Generate time slots for the day
    const startHour = 8
    const endHour = 20
    const slotInterval = 30 // minutes
    
    for (let hour = startHour; hour < endHour; hour++) {
      for (let minute = 0; minute < 60; minute += slotInterval) {
        const slotStart = new Date(date)
        slotStart.setHours(hour, minute, 0, 0)
        
        const slotEnd = new Date(slotStart.getTime() + duration * 60000)
        
        // Check if slot is within working hours for all participants
        let availableParticipants = 0
        
        for (const participant of participants) {
          const workingHours = participant.workingHours || defaultWorkingHours
          
          if (this.isWorkingHours(slotStart, participant.timeZone, workingHours) &&
              this.isWorkingHours(slotEnd, participant.timeZone, workingHours)) {
            availableParticipants++
          }
        }
        
        if (availableParticipants > 0) {
          const confidence = availableParticipants / participants.length
          slots.push({
            start: slotStart,
            end: slotEnd,
            confidence
          })
        }
      }
    }
    
    return slots
  }

  static detectUserTimeZone(): string {
    return Intl.DateTimeFormat().resolvedOptions().timeZone
  }

  static validateTimeZone(timeZone: string): boolean {
    try {
      Intl.DateTimeFormat('en-US', { timeZone })
      return true
    } catch {
      return false
    }
  }
}