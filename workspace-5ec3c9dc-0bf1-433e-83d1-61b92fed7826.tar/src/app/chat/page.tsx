"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { 
  MessageSquare, 
  Send, 
  Paperclip, 
  Mic, 
  MoreHorizontal, 
  Clock, 
  CheckCheck,
  Calendar,
  Target,
  Users,
  Settings,
  Plus,
  Search
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useSocket } from "@/hooks/useSocket"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
  actions?: Action[]
}

interface Action {
  id: string
  label: string
  type: "confirm" | "decline" | "suggest" | "priority" | "schedule"
  data?: any
}

interface ChatThread {
  id: string
  title: string
  description: string
  category: string
  lastMessage: string
  lastMessageTime: Date
  unread: number
}

const chatThreads: ChatThread[] = [
  {
    id: "1",
    title: "Daily Schedule",
    description: "Planning today's tasks and priorities",
    category: "scheduling",
    lastMessage: "I've optimized your schedule for maximum productivity",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
    unread: 0
  },
  {
    id: "2",
    title: "DevOps Plan",
    description: "Career development and infrastructure migration",
    category: "goals",
    lastMessage: "Let's break this down into manageable milestones",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
    unread: 2
  },
  {
    id: "3",
    title: "Team Coordination",
    description: "Working with the development team",
    category: "team",
    lastMessage: "I've scheduled the standup for 10:30 AM",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
    unread: 0
  }
]

const initialMessages: Message[] = [
  {
    id: "1",
    content: "Good morning! I'm here to help you plan your day. What are your main priorities for today?",
    role: "assistant",
    timestamp: new Date(Date.now() - 1000 * 60 * 10),
  },
  {
    id: "2",
    content: "I need to finish the Q4 strategy review, prepare for the client presentation, and have a team standup meeting.",
    role: "user",
    timestamp: new Date(Date.now() - 1000 * 60 * 8),
  },
  {
    id: "3",
    content: "Perfect! I can help you organize these tasks. Based on your priorities and calendar, here's what I recommend:\n\n1. **Q4 Strategy Review** (9:00 AM - 10:30 AM)\n   - High priority, requires focus\n   - Best done in the morning when you're fresh\n\n2. **Team Standup** (10:30 AM - 11:00 AM)\n   - Already scheduled\n   - Quick coordination with the team\n\n3. **Client Presentation Prep** (2:00 PM - 4:00 PM)\n   - Allows time for final review\n   - Gives you morning to focus on strategy\n\nDoes this schedule work for you?",
    role: "assistant",
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
    actions: [
      { id: "1", label: "Confirm Schedule", type: "confirm" },
      { id: "2", label: "Suggest Another Time", type: "suggest" },
      { id: "3", label: "Adjust Priorities", type: "priority" }
    ]
  }
]

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [inputValue, setInputValue] = useState("")
  const [selectedThread, setSelectedThread] = useState("1")
  const [isSending, setIsSending] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Initialize socket connection
  const { 
    isConnected, 
    sendChatMessage, 
    joinThread, 
    leaveThread, 
    startTyping, 
    stopTyping,
    isUserTyping 
  } = useSocket({ 
    userId: "demo-user", // In real app, get from auth
    token: "demo-token" // In real app, get from auth
  })

  // Join thread when selected
  useEffect(() => {
    if (selectedThread && isConnected) {
      joinThread(selectedThread)
      
      return () => {
        leaveThread(selectedThread)
      }
    }
  }, [selectedThread, isConnected, joinThread, leaveThread])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleInputChange = (value: string) => {
    setInputValue(value)
    
    if (value.trim() && !isTyping) {
      setIsTyping(true)
      startTyping(selectedThread)
    } else if (!value.trim() && isTyping) {
      setIsTyping(false)
      stopTyping(selectedThread)
    }
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isSending) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      role: "user",
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue("")
    setIsSending(true)

    // Send real-time message
    sendChatMessage(selectedThread, inputValue)

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "I understand! Let me help you with that. Based on your request, I can suggest a few options that would work well with your current schedule and priorities.",
        role: "assistant",
        timestamp: new Date(),
        actions: [
          { id: "1", label: "Confirm", type: "confirm" },
          { id: "2", label: "Decline", type: "decline" },
          { id: "3", label: "Suggest Another Time", type: "suggest" }
        ]
      }
      setMessages(prev => [...prev, aiMessage])
      setIsSending(false)
    }, 1500)
  }

  const handleAction = (action: Action) => {
    // Handle action button clicks
    const actionMessage: Message = {
      id: Date.now().toString(),
      content: `You selected: ${action.label}`,
      role: "user",
      timestamp: new Date()
    }
    setMessages(prev => [...prev, actionMessage])

    // Simulate AI response to action
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: `Great! I've ${action.label.toLowerCase()} your request. Your schedule has been updated accordingly.`,
        role: "assistant",
        timestamp: new Date()
      }
      setMessages(prev => [...prev, aiResponse])
    }, 1000)
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "scheduling": return <Calendar className="h-4 w-4" />
      case "goals": return <Target className="h-4 w-4" />
      case "team": return <Users className="h-4 w-4" />
      default: return <MessageSquare className="h-4 w-4" />
    }
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Connection Status */}
      <div className="fixed top-4 right-4 z-50">
        <Badge variant={isConnected ? "default" : "destructive"}>
          {isConnected ? "Connected" : "Disconnected"}
        </Badge>
      </div>

      {/* Chat Threads Sidebar */}
      <div className="w-80 border-r bg-card flex flex-col">
        <div className="p-4 border-b">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-lg">Chats</h2>
            <Button size="sm" variant="ghost">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search chats..." className="pl-10" />
          </div>
        </div>
        
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-2">
            {chatThreads.map((thread) => (
              <div
                key={thread.id}
                className={cn(
                  "p-3 rounded-lg cursor-pointer transition-colors hover:bg-accent",
                  selectedThread === thread.id ? "bg-accent" : ""
                )}
                onClick={() => setSelectedThread(thread.id)}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      {getCategoryIcon(thread.category)}
                      <h3 className="font-medium text-sm truncate">{thread.title}</h3>
                      {thread.unread > 0 && (
                        <Badge variant="destructive" className="h-5 w-5 p-0 text-xs">
                          {thread.unread}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                      {thread.description}
                    </p>
                    <div className="flex items-center gap-1">
                      <p className="text-xs text-muted-foreground truncate">
                        {thread.lastMessage}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-muted-foreground">
                    {formatTime(thread.lastMessageTime)}
                  </span>
                  <CheckCheck className="h-3 w-3 text-muted-foreground" />
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Chat Window */}
      <div className="flex-1 flex flex-col">
        {/* Chat Header */}
        <div className="h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex h-full items-center justify-between px-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold">Daily Schedule</h2>
                <p className="text-sm text-muted-foreground">Planning today's tasks and priorities</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm">
                <Clock className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Messages Area */}
        <ScrollArea className="flex-1 p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  "flex gap-4",
                  message.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                {message.role === "assistant" && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      N
                    </AvatarFallback>
                  </Avatar>
                )}
                
                <div className={cn(
                  "max-w-[70%] space-y-3",
                  message.role === "user" ? "order-1" : "order-2"
                )}>
                  <div className={cn(
                    "p-4 rounded-lg",
                    message.role === "user" 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted"
                  )}>
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  </div>
                  
                  {message.actions && (
                    <div className="flex flex-wrap gap-2">
                      {message.actions.map((action) => (
                        <Button
                          key={action.id}
                          variant="outline"
                          size="sm"
                          onClick={() => handleAction(action)}
                          className={cn(
                            "text-xs",
                            action.type === "confirm" && "border-green-500 text-green-700 hover:bg-green-50",
                            action.type === "decline" && "border-red-500 text-red-700 hover:bg-red-50"
                          )}
                        >
                          {action.label}
                        </Button>
                      ))}
                    </div>
                  )}
                  
                  <div className={cn(
                    "flex items-center gap-1 text-xs text-muted-foreground",
                    message.role === "user" ? "justify-end" : "justify-start"
                  )}>
                    <span>{formatTime(message.timestamp)}</span>
                    {message.role === "user" && <CheckCheck className="h-3 w-3" />}
                  </div>
                </div>

                {message.role === "user" && (
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder-avatar.jpg" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            
            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-4">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    N
                  </AvatarFallback>
                </Avatar>
                <div className="bg-muted rounded-lg px-4 py-2">
                  <div className="flex gap-1">
                    <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="border-t p-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" className="shrink-0">
                <Paperclip className="h-4 w-4" />
              </Button>
              <div className="flex-1 relative">
                <Input
                  value={inputValue}
                  onChange={(e) => handleInputChange(e.target.value)}
                  placeholder="Type your message..."
                  className="pr-12"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSendMessage()
                    }
                  }}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1/2 -translate-y-1/2"
                >
                  <Mic className="h-4 w-4" />
                </Button>
              </div>
              <Button 
                onClick={handleSendMessage} 
                disabled={!inputValue.trim() || isSending}
                className="shrink-0"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}