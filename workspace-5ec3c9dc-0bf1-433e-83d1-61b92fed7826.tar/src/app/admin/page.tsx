"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { 
  Users, 
  DollarSign, 
  TrendingUp, 
  Activity, 
  Search,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Calendar,
  MessageSquare,
  Target,
  Settings
} from "lucide-react"

interface User {
  id: string
  email: string
  name?: string
  avatar?: string
  createdAt: string
  lastLogin?: string
  subscriptionTier: string
  lifetimeAccess: boolean
  googleCalendarConnected: boolean
}

interface Metric {
  label: string
  value: string
  change: string
  icon: any
  color: string
}

const mockUsers: User[] = [
  {
    id: "1",
    email: "john@example.com",
    name: "John Doe",
    createdAt: "2024-01-15",
    lastLogin: "2024-01-20",
    subscriptionTier: "premium",
    lifetimeAccess: false,
    googleCalendarConnected: true
  },
  {
    id: "2",
    email: "jane@example.com",
    name: "Jane Smith",
    createdAt: "2024-01-10",
    lastLogin: "2024-01-19",
    subscriptionTier: "free",
    lifetimeAccess: true,
    googleCalendarConnected: false
  },
  {
    id: "3",
    email: "bob@example.com",
    name: "Bob Johnson",
    createdAt: "2024-01-18",
    lastLogin: "2024-01-20",
    subscriptionTier: "pro",
    lifetimeAccess: false,
    googleCalendarConnected: true
  }
]

const mockMetrics: Metric[] = [
  {
    label: "Total Users",
    value: "1,234",
    change: "+12.5%",
    icon: Users,
    color: "text-blue-600"
  },
  {
    label: "Active Subscriptions",
    value: "856",
    change: "+8.2%",
    icon: DollarSign,
    color: "text-green-600"
  },
  {
    label: "Monthly Revenue",
    value: "$12,450",
    change: "+15.3%",
    icon: TrendingUp,
    color: "text-purple-600"
  },
  {
    label: "User Engagement",
    value: "89%",
    change: "+3.1%",
    icon: Activity,
    color: "text-orange-600"
  }
]

export default function AdminDashboard() {
  const [users, setUsers] = useState<User[]>(mockUsers)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedUser, setSelectedUser] = useState<User | null>(null)

  const filteredUsers = users.filter(user =>
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.name?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleLifetimeAccessToggle = (userId: string, checked: boolean) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, lifetimeAccess: checked } : user
    ))
  }

  const getSubscriptionBadgeColor = (tier: string) => {
    switch (tier) {
      case "premium": return "bg-blue-100 text-blue-800"
      case "pro": return "bg-purple-100 text-purple-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage your Nexus platform and monitor performance</p>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {mockMetrics.map((metric) => (
            <Card key={metric.label}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{metric.label}</CardTitle>
                <metric.icon className={`h-4 w-4 ${metric.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metric.value}</div>
                <p className="text-xs text-muted-foreground">
                  {metric.change} from last month
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="users" className="space-y-6">
          <TabsList>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="ai-logs">AI Logs</TabsTrigger>
            <TabsTrigger value="system">System Health</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-6">
            {/* User Management */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>Manage user accounts and permissions</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search users..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Subscription</TableHead>
                      <TableHead>Google Calendar</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead>Last Login</TableHead>
                      <TableHead>Lifetime Access</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={user.avatar} />
                              <AvatarFallback>{user.name?.[0] || user.email[0]}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{user.name || 'Unknown'}</div>
                                  <div className="text-sm text-muted-foreground">{user.email}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={getSubscriptionBadgeColor(user.subscriptionTier)}>
                                {user.subscriptionTier}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={user.googleCalendarConnected ? "default" : "secondary"}>
                                {user.googleCalendarConnected ? "Connected" : "Not Connected"}
                              </Badge>
                            </TableCell>
                            <TableCell>{new Date(user.createdAt).toLocaleDateString()}</TableCell>
                            <TableCell>
                              {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never'}
                            </TableCell>
                            <TableCell>
                              <Switch
                                checked={user.lifetimeAccess}
                                onCheckedChange={(checked) => handleLifetimeAccessToggle(user.id, checked)}
                              />
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button variant="ghost" size="sm">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="subscriptions" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Subscription Management</CardTitle>
                    <CardDescription>Manage subscription tiers and billing</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-4">
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Free</CardTitle>
                            <CardDescription>Basic features for individuals</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span>Price</span>
                                <span className="font-bold">$0/month</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Active Users</span>
                                <span>378</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card className="border-primary">
                          <CardHeader>
                            <CardTitle className="text-lg">Premium</CardTitle>
                            <CardDescription>Advanced features for professionals</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span>Price</span>
                                <span className="font-bold">$19/month</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Active Users</span>
                                <span>412</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Pro</CardTitle>
                            <CardDescription>Everything for teams</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span>Price</span>
                                <span className="font-bold">$49/month</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Active Users</span>
                                <span>66</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Analytics</CardTitle>
                    <CardDescription>Track user engagement and platform usage</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <h3 className="font-semibold mb-4">Feature Usage</h3>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4" />
                              <span>Scheduling</span>
                            </div>
                            <span>89%</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Target className="h-4 w-4" />
                              <span>Goals</span>
                            </div>
                            <span>76%</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <MessageSquare className="h-4 w-4" />
                              <span>Chat</span>
                            </div>
                            <span>92%</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4" />
                              <span>Teams</span>
                            </div>
                            <span>34%</span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-4">User Activity</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span>Daily Active Users</span>
                            <span className="font-bold">1,156</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Weekly Active Users</span>
                            <span className="font-bold">2,891</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Monthly Active Users</span>
                            <span className="font-bold">4,567</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Average Session Duration</span>
                            <span className="font-bold">24m 32s</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="ai-logs" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>AI Interaction Logs</CardTitle>
                    <CardDescription>Monitor AI performance and user interactions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-4 gap-4 text-center">
                        <div>
                          <div className="text-2xl font-bold">45,678</div>
                          <div className="text-sm text-muted-foreground">Total Interactions</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-green-600">98.2%</div>
                          <div className="text-sm text-muted-foreground">Success Rate</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold">1.2s</div>
                          <div className="text-sm text-muted-foreground">Avg Response Time</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold">4.6</div>
                          <div className="text-sm text-muted-foreground">Avg Rating</div>
                        </div>
                      </div>
                      
                      <div className="border rounded-lg">
                        <div className="p-4 border-b">
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-medium">User: "Help me schedule my day"</div>
                              <div className="text-sm text-muted-foreground">2 minutes ago</div>
                            </div>
                            <Badge variant="outline">Scheduling</Badge>
                          </div>
                        </div>
                        <div className="p-4 bg-muted/50">
                          <div className="text-sm">
                            AI: "I'll help you organize your day. Based on your priorities and calendar, here's what I recommend..."
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="system" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>System Health</CardTitle>
                    <CardDescription>Monitor server status and performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <h3 className="font-semibold mb-4">Server Status</h3>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span>API Server</span>
                            <Badge variant="default">Online</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span>Database</span>
                            <Badge variant="default">Connected</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span>Google Calendar API</span>
                            <Badge variant="default">Operational</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span>AI Service</span>
                            <Badge variant="default">Available</Badge>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-4">Performance Metrics</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span>CPU Usage</span>
                            <span>23%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Memory Usage</span>
                            <span>67%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Disk Usage</span>
                            <span>45%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Uptime</span>
                            <span>99.9%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )
    }