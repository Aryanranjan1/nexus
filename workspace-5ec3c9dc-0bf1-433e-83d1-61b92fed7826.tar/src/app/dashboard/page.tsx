"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Bell, Search, Calendar, Target, MessageSquare, Users, Settings, LayoutDashboard, ChevronRight, Clock } from "lucide-react"
import { cn } from "@/lib/utils"

const navigation = [
  { name: "Dashboard", icon: LayoutDashboard, current: true },
  { name: "Chats", icon: MessageSquare, current: false },
  { name: "Calendar", icon: Calendar, current: false },
  { name: "Goals", icon: Target, current: false },
  { name: "Team", icon: Users, current: false },
  { name: "Settings", icon: Settings, current: false },
]

const todayTasks = [
  { id: 1, title: "Review Q4 Strategy", time: "9:00 AM", priority: "high", completed: false },
  { id: 2, title: "Team Standup Meeting", time: "10:30 AM", priority: "medium", completed: false },
  { id: 3, title: "Client Presentation Prep", time: "2:00 PM", priority: "high", completed: false },
]

const weeklyEvents = [
  { day: "Mon", date: "18", events: 2 },
  { day: "Tue", date: "19", events: 3, isToday: true },
  { day: "Wed", date: "20", events: 1 },
  { day: "Thu", date: "21", events: 4 },
  { day: "Fri", date: "22", events: 2 },
  { day: "Sat", date: "23", events: 0 },
  { day: "Sun", date: "24", events: 0 },
]

const activeGoals = [
  { title: "DevOps Plan", progress: 30, target: "Complete infrastructure migration", deadline: "Dec 31" },
  { title: "Fitness Goal", progress: 65, target: "Run 5K without stopping", deadline: "Nov 30" },
]

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-card border-r transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex h-16 items-center px-6 border-b">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">N</span>
              </div>
              <span className="font-bold text-xl">Nexus</span>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-1 px-3 py-4">
            {navigation.map((item) => (
              <a
                key={item.name}
                href="#"
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  item.current
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.name}
              </a>
            ))}
          </nav>

          {/* User Profile */}
          <div className="border-t p-4">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarImage src="/placeholder-avatar.jpg" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">John Doe</p>
                <p className="text-xs text-muted-foreground truncate">john@example.com</p>
              </div>
              <Badge variant="secondary">Free</Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex h-full items-center justify-between px-6">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </Button>
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search..."
                  className="pl-10 w-64"
                />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <Avatar>
                <AvatarImage src="/placeholder-avatar.jpg" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Welcome Section */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">Welcome back, John!</h1>
                <p className="text-muted-foreground">Here's what's happening with your productivity today.</p>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span>Last updated: 2 minutes ago</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Today's Focus */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5" />
                      Today's Focus
                    </CardTitle>
                    <CardDescription>Your top 3 high-priority tasks for today</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {todayTasks.map((task) => (
                      <div key={task.id} className="flex items-center gap-4 p-4 rounded-lg border">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{task.title}</h4>
                            <Badge variant={task.priority === "high" ? "destructive" : "secondary"}>
                              {task.priority}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{task.time}</p>
                        </div>
                        <Button variant="ghost" size="sm">
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* Weekly Outlook */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Weekly Outlook
                  </CardTitle>
                  <CardDescription>Your schedule at a glance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-7 gap-1">
                    {weeklyEvents.map((day) => (
                      <div
                        key={day.day}
                        className={cn(
                          "flex flex-col items-center p-2 rounded-lg text-center",
                          day.isToday ? "bg-primary text-primary-foreground" : "hover:bg-accent"
                        )}
                      >
                        <span className="text-xs font-medium">{day.day}</span>
                        <span className="text-sm font-bold">{day.date}</span>
                        {day.events > 0 && (
                          <div className="mt-1 flex items-center justify-center">
                            <div className="h-1 w-1 rounded-full bg-current opacity-70" />
                            <span className="text-xs ml-1">{day.events}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Today's Events</span>
                      <span className="font-medium">3 events</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Free Time</span>
                      <span className="font-medium text-green-600">4 hours</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Goal Progress */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {activeGoals.map((goal, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5" />
                      {goal.title}
                    </CardTitle>
                    <CardDescription>{goal.target}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Progress</span>
                        <span className="text-sm font-medium">{goal.progress}%</span>
                      </div>
                      <Progress value={goal.progress} className="h-2" />
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Deadline</span>
                        <span className="font-medium">{goal.deadline}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Get started with these common tasks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button variant="outline" className="h-20 flex-col gap-2">
                    <MessageSquare className="h-6 w-6" />
                    <span className="text-sm">New Chat</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col gap-2">
                    <Calendar className="h-6 w-6" />
                    <span className="text-sm">Schedule</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col gap-2">
                    <Target className="h-6 w-6" />
                    <span className="text-sm">Add Goal</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col gap-2">
                    <Users className="h-6 w-6" />
                    <span className="text-sm">Invite Team</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}