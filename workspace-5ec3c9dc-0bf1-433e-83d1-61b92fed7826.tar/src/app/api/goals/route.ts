import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const category = searchParams.get('category')
    const status = searchParams.get('status')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const where: any = { userId }
    
    if (category) where.category = category
    if (status) where.status = status

    const goals = await db.goal.findMany({
      where,
      include: {
        steps: {
          orderBy: { order: 'asc' }
        },
        schedules: {
          orderBy: { startTime: 'asc' }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(goals)
  } catch (error) {
    console.error('Error fetching goals:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const {
      title,
      description,
      category,
      targetDate,
      priority,
      userId,
      steps
    } = data

    // Validate required fields
    if (!title || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Create the goal
    const goal = await db.goal.create({
      data: {
        title,
        description,
        category: category || 'personal',
        targetDate: targetDate ? new Date(targetDate) : null,
        priority: priority || 'medium',
        userId
      },
      include: {
        steps: true
      }
    })

    // Create steps if provided
    if (steps && Array.isArray(steps) && steps.length > 0) {
      const stepData = steps.map((step: any, index: number) => ({
        title: step.title,
        description: step.description,
        dueDate: step.dueDate ? new Date(step.dueDate) : null,
        order: index,
        goalId: goal.id
      }))

      await db.goalStep.createMany({
        data: stepData
      })

      // Fetch the goal with steps
      const goalWithSteps = await db.goal.findUnique({
        where: { id: goal.id },
        include: {
          steps: {
            orderBy: { order: 'asc' }
          }
        }
      })

      return NextResponse.json(goalWithSteps)
    }

    return NextResponse.json(goal)
  } catch (error) {
    console.error('Error creating goal:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}