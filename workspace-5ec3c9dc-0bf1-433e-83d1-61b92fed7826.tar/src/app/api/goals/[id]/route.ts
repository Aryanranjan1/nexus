import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const data = await request.json()
    const { id } = params

    // Update goal progress if steps are provided
    if (data.steps) {
      const completedSteps = data.steps.filter((step: any) => step.completed).length
      const totalSteps = data.steps.length
      const progress = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0

      data.progress = progress

      // Update goal status based on progress
      if (progress === 100) {
        data.status = 'completed'
      } else if (progress > 0) {
        data.status = 'active'
      }
    }

    const goal = await db.goal.update({
      where: { id },
      data,
      include: {
        steps: {
          orderBy: { order: 'asc' }
        },
        schedules: {
          orderBy: { startTime: 'asc' }
        }
      }
    })

    return NextResponse.json(goal)
  } catch (error) {
    console.error('Error updating goal:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // Delete associated steps first
    await db.goalStep.deleteMany({
      where: { goalId: id }
    })

    // Delete the goal
    await db.goal.delete({
      where: { id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting goal:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}