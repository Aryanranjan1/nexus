import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const data = await request.json()
    const { id } = params
    const { title, description, dueDate } = data

    if (!title) {
      return NextResponse.json({ error: 'Step title is required' }, { status: 400 })
    }

    // Get the current highest order for this goal
    const lastStep = await db.goalStep.findFirst({
      where: { goalId: id },
      orderBy: { order: 'desc' }
    })

    const newOrder = lastStep ? lastStep.order + 1 : 0

    const step = await db.goalStep.create({
      data: {
        title,
        description,
        dueDate: dueDate ? new Date(dueDate) : null,
        order: newOrder,
        goalId: id
      }
    })

    // Update goal progress
    await updateGoalProgress(id)

    return NextResponse.json(step)
  } catch (error) {
    console.error('Error creating goal step:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const data = await request.json()
    const { id } = params
    const { steps } = data

    if (!Array.isArray(steps)) {
      return NextResponse.json({ error: 'Steps must be an array' }, { status: 400 })
    }

    // Update each step
    for (const step of steps) {
      await db.goalStep.update({
        where: { id: step.id },
        data: {
          title: step.title,
          description: step.description,
          completed: step.completed,
          dueDate: step.dueDate ? new Date(step.dueDate) : null,
          order: step.order
        }
      })
    }

    // Update goal progress
    await updateGoalProgress(id)

    // Get updated goal with steps
    const goal = await db.goal.findUnique({
      where: { id },
      include: {
        steps: {
          orderBy: { order: 'asc' }
        }
      }
    })

    return NextResponse.json(goal)
  } catch (error) {
    console.error('Error updating goal steps:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

async function updateGoalProgress(goalId: string) {
  const steps = await db.goalStep.findMany({
    where: { goalId }
  })

  const completedSteps = steps.filter(step => step.completed).length
  const totalSteps = steps.length
  const progress = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0

  let status = 'active'
  if (progress === 100) {
    status = 'completed'
  } else if (completedSteps === 0) {
    status = 'active'
  }

  await db.goal.update({
    where: { id: goalId },
    data: {
      progress,
      status
    }
  })
}