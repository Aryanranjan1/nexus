import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    const chatThread = await db.chatThread.findUnique({
      where: { id },
      include: {
        messages: {
          orderBy: { timestamp: 'asc' }
        }
      }
    })

    if (!chatThread) {
      return NextResponse.json({ error: 'Chat thread not found' }, { status: 404 })
    }

    return NextResponse.json(chatThread)
  } catch (error) {
    console.error('Error fetching chat thread:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const data = await request.json()
    const { id } = params

    const chatThread = await db.chatThread.update({
      where: { id },
      data
    })

    return NextResponse.json(chatThread)
  } catch (error) {
    console.error('Error updating chat thread:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // Delete associated messages first
    await db.chatMessage.deleteMany({
      where: { threadId: id }
    })

    // Delete the chat thread
    await db.chatThread.delete({
      where: { id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting chat thread:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}