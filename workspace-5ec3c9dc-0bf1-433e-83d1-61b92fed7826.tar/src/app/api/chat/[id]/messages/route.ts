import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

interface ChatMessageRequest {
  content: string
  role: 'user' | 'assistant'
  metadata?: string
}

interface AIResponse {
  content: string
  actions?: Array<{
    id: string
    label: string
    type: 'confirm' | 'decline' | 'suggest' | 'priority' | 'schedule'
    data?: any
  }>
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const data: ChatMessageRequest = await request.json()
    const { content, role, metadata } = data

    if (!content || !role) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Create the message
    const message = await db.chatMessage.create({
      data: {
        content,
        role,
        metadata: metadata || null,
        threadId: id
      }
    })

    // If it's a user message, generate AI response
    if (role === 'user') {
      try {
        const aiResponse = await generateAIResponse(content, id)
        
        // Create AI response message
        const aiMessage = await db.chatMessage.create({
          data: {
            content: aiResponse.content,
            role: 'assistant',
            metadata: aiResponse.actions ? JSON.stringify({ actions: aiResponse.actions }) : null,
            threadId: id
          }
        })

        // Track AI interaction
        await trackAIInteraction(id, content, aiResponse.content)

        return NextResponse.json({
          userMessage: message,
          aiMessage: aiMessage,
          actions: aiResponse.actions
        })
      } catch (aiError) {
        console.error('Error generating AI response:', aiError)
        
        // Create fallback AI message
        const fallbackMessage = await db.chatMessage.create({
          data: {
            content: "I'm sorry, I'm having trouble responding right now. Please try again later.",
            role: 'assistant',
            threadId: id
          }
        })

        return NextResponse.json({
          userMessage: message,
          aiMessage: fallbackMessage,
          error: 'AI service unavailable'
        })
      }
    }

    return NextResponse.json(message)
  } catch (error) {
    console.error('Error creating chat message:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

async function generateAIResponse(userMessage: string, threadId: string): Promise<AIResponse> {
  const zai = await ZAI.create()

  // Get chat thread context
  const chatThread = await db.chatThread.findUnique({
    where: { id: threadId },
    include: {
      user: true,
      messages: {
        orderBy: { timestamp: 'desc' },
        take: 10 // Get last 10 messages for context
      }
    }
  })

  if (!chatThread) {
    throw new Error('Chat thread not found')
  }

  // Build system prompt based on thread category
  let systemPrompt = `You are Nexus, an AI assistant for the Nexus productivity platform. You help users manage their schedules, goals, and team collaboration.`

  switch (chatThread.category) {
    case 'scheduling':
      systemPrompt += ` You specialize in intelligent scheduling, time optimization, and calendar management. Help users organize their time effectively and suggest optimal schedules.`
      break
    case 'goals':
      systemPrompt += ` You specialize in goal setting, progress tracking, and milestone planning. Help users break down their goals into actionable steps and stay motivated.`
      break
    case 'team':
      systemPrompt += ` You specialize in team coordination, collaboration, and communication. Help users manage team schedules and facilitate effective teamwork.`
      break
    default:
      systemPrompt += ` You are a general productivity assistant. Help users with various aspects of their work and personal life management.`
  }

  systemPrompt += `
  
  Guidelines:
  - Be helpful, concise, and actionable
  - Provide specific suggestions when possible
  - Use the user's context (schedule, goals, team) when making recommendations
  - Suggest practical next steps
  - Keep responses focused on productivity and time management
  
  When appropriate, suggest actions that the user can take. These should be presented as clear, actionable buttons.`

  // Prepare conversation history
  const conversationHistory = chatThread.messages
    .filter(msg => msg.role !== 'system')
    .reverse()
    .map(msg => ({
      role: msg.role,
      content: msg.content
    }))

  // Generate AI response
  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'system',
        content: systemPrompt
      },
      ...conversationHistory,
      {
        role: 'user',
        content: userMessage
      }
    ]
  })

  const aiContent = completion.choices[0]?.message?.content || "I'm here to help you with your productivity needs."

  // Generate appropriate actions based on the response
  const actions = generateActions(aiContent, userMessage, chatThread.category)

  return {
    content: aiContent,
    actions
  }
}

function generateActions(aiContent: string, userMessage: string, category: string): AIResponse['actions'] {
  const actions: AIResponse['actions'] = []

  // Common actions for all categories
  actions.push(
    { id: 'confirm', label: 'Confirm', type: 'confirm' },
    { id: 'decline', label: 'Decline', type: 'decline' }
  )

  // Category-specific actions
  switch (category) {
    case 'scheduling':
      if (userMessage.toLowerCase().includes('schedule') || userMessage.toLowerCase().includes('time')) {
        actions.push(
          { id: 'suggest-time', label: 'Suggest Another Time', type: 'suggest' },
          { id: 'set-priority', label: 'Set Priority: High', type: 'priority' }
        )
      }
      break
    
    case 'goals':
      if (userMessage.toLowerCase().includes('goal') || userMessage.toLowerCase().includes('target')) {
        actions.push(
          { id: 'add-milestone', label: 'Add Milestone', type: 'schedule' },
          { id: 'set-deadline', label: 'Set Deadline', type: 'schedule' }
        )
      }
      break
    
    case 'team':
      if (userMessage.toLowerCase().includes('meeting') || userMessage.toLowerCase().includes('team')) {
        actions.push(
          { id: 'schedule-meeting', label: 'Schedule Meeting', type: 'schedule' },
          { id: 'invite-team', label: 'Invite Team Member', type: 'confirm' }
        )
      }
      break
  }

  // Limit to 4 actions maximum
  return actions.slice(0, 4)
}

async function trackAIInteraction(
  threadId: string,
  userInput: string,
  aiOutput: string
) {
  try {
    // Get user ID from chat thread
    const chatThread = await db.chatThread.findUnique({
      where: { id: threadId },
      select: { userId: true }
    })

    if (!chatThread) return

    await db.aiInteraction.create({
      data: {
        input: userInput,
        output: aiOutput,
        model: '0727-360B-API', // Default model
        success: true,
        userId: chatThread.userId
      }
    })
  } catch (error) {
    console.error('Error tracking AI interaction:', error)
    // Don't fail the whole operation if tracking fails
  }
}