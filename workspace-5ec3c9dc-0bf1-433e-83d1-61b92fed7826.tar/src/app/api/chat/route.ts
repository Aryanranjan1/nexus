import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const chatThreads = await db.chatThread.findMany({
      where: { userId },
      include: {
        messages: {
          orderBy: { timestamp: 'asc' },
          take: 1 // Only get the last message for preview
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    })

    return NextResponse.json(chatThreads)
  } catch (error) {
    console.error('Error fetching chat threads:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { title, description, category, userId } = data

    if (!title || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const chatThread = await db.chatThread.create({
      data: {
        title,
        description,
        category: category || 'general',
        userId
      }
    })

    return NextResponse.json(chatThread)
  } catch (error) {
    console.error('Error creating chat thread:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}