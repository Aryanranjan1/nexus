import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const where: any = { userId }
    
    if (startDate && endDate) {
      where.startTime = {
        gte: new Date(startDate),
        lte: new Date(endDate)
      }
    }

    const schedules = await db.schedule.findMany({
      where,
      include: {
        goal: true,
        team: true
      },
      orderBy: {
        startTime: 'asc'
      }
    })

    return NextResponse.json(schedules)
  } catch (error) {
    console.error('Error fetching schedules:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const {
      title,
      description,
      startTime,
      endTime,
      allDay,
      location,
      priority,
      category,
      userId,
      goalId,
      teamId,
      aiGenerated
    } = data

    // Validate required fields
    if (!title || !startTime || !endTime || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Check for time conflicts
    const conflicts = await db.schedule.findMany({
      where: {
        userId,
        OR: [
          {
            AND: [
              { startTime: { lte: new Date(startTime) } },
              { endTime: { gte: new Date(startTime) } }
            ]
          },
          {
            AND: [
              { startTime: { lte: new Date(endTime) } },
              { endTime: { gte: new Date(endTime) } }
            ]
          },
          {
            AND: [
              { startTime: { gte: new Date(startTime) } },
              { endTime: { lte: new Date(endTime) } }
            ]
          }
        ],
        status: { not: 'cancelled' }
      }
    })

    if (conflicts.length > 0) {
      return NextResponse.json({ 
        error: 'Schedule conflict detected',
        conflicts 
      }, { status: 409 })
    }

    const schedule = await db.schedule.create({
      data: {
        title,
        description,
        startTime: new Date(startTime),
        endTime: new Date(endTime),
        allDay: allDay || false,
        location,
        priority: priority || 'medium',
        category,
        userId,
        goalId,
        teamId,
        aiGenerated: aiGenerated || false
      },
      include: {
        goal: true,
        team: true
      }
    })

    return NextResponse.json(schedule)
  } catch (error) {
    console.error('Error creating schedule:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}