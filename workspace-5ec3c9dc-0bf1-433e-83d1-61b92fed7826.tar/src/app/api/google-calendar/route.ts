import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { GoogleCalendarService } from '@/lib/services/google-calendar'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Get user with Google Calendar token
    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        googleCalendarToken: true,
        googleCalendarId: true,
        timezone: true
      }
    })

    if (!user?.googleCalendarToken) {
      return NextResponse.json({ error: 'Google Calendar not connected' }, { status: 400 })
    }

    if (!startDate || !endDate) {
      return NextResponse.json({ error: 'Start and end dates are required' }, { status: 400 })
    }

    // Initialize Google Calendar service
    const calendarService = new GoogleCalendarService(user.googleCalendarToken)

    // Fetch events from Google Calendar
    const events = await calendarService.listEvents(
      user.googleCalendarId || 'primary',
      new Date(startDate),
      new Date(endDate)
    )

    return NextResponse.json(events)
  } catch (error) {
    console.error('Error fetching Google Calendar events:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { userId, summary, description, start, end, location, calendarId } = data

    if (!userId || !summary || !start || !end) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Get user with Google Calendar token
    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        googleCalendarToken: true,
        googleCalendarId: true,
        timezone: true
      }
    })

    if (!user?.googleCalendarToken) {
      return NextResponse.json({ error: 'Google Calendar not connected' }, { status: 400 })
    }

    // Initialize Google Calendar service
    const calendarService = new GoogleCalendarService(user.googleCalendarToken)

    // Create event in Google Calendar
    const event = await calendarService.createEvent({
      summary,
      description,
      start: new Date(start),
      end: new Date(end),
      location,
      timeZone: user.timezone || 'UTC'
    }, calendarId || user.googleCalendarId || 'primary')

    return NextResponse.json(event)
  } catch (error) {
    console.error('Error creating Google Calendar event:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}