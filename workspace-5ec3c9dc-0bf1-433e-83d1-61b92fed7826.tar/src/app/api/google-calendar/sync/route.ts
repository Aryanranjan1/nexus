import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { GoogleCalendarService } from '@/lib/services/google-calendar'

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { userId, startDate, endDate } = data

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Get user with Google Calendar token
    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        googleCalendarToken: true,
        googleCalendarId: true,
        timezone: true
      }
    })

    if (!user?.googleCalendarToken) {
      return NextResponse.json({ error: 'Google Calendar not connected' }, { status: 400 })
    }

    // Get date range for sync
    const syncStartDate = startDate ? new Date(startDate) : new Date()
    const syncEndDate = endDate ? new Date(endDate) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now

    // Get Nexus schedules for the date range
    const nexusSchedules = await db.schedule.findMany({
      where: {
        userId,
        startTime: {
          gte: syncStartDate,
          lte: syncEndDate
        },
        status: { not: 'cancelled' }
      },
      orderBy: {
        startTime: 'asc'
      }
    })

    // Initialize Google Calendar service
    const calendarService = new GoogleCalendarService(user.googleCalendarToken)

    // Sync events to Google Calendar
    const syncResults = await calendarService.syncEvents(
      nexusSchedules.map(schedule => ({
        id: schedule.id,
        title: schedule.title,
        description: schedule.description,
        startTime: schedule.startTime,
        endTime: schedule.endTime,
        location: schedule.location,
        googleCalendarEventId: schedule.googleCalendarEventId || undefined
      })),
      user.googleCalendarId || 'primary'
    )

    // Update Nexus schedules with Google Calendar event IDs
    for (const result of syncResults) {
      if (result.action === 'created' || result.action === 'updated') {
        await db.schedule.update({
          where: { id: result.nexusEventId },
          data: {
            googleCalendarEventId: result.googleEventId
          }
        })
      }
    }

    // Get Google Calendar events and sync back to Nexus
    const googleEvents = await calendarService.listEvents(
      user.googleCalendarId || 'primary',
      syncStartDate,
      syncEndDate
    )

    // Create or update Nexus schedules from Google Calendar events
    for (const googleEvent of googleEvents) {
      if (googleEvent.start?.dateTime && googleEvent.end?.dateTime) {
        const existingSchedule = await db.schedule.findFirst({
          where: {
            userId,
            googleCalendarEventId: googleEvent.id
          }
        })

        if (!existingSchedule) {
          // Create new Nexus schedule from Google Calendar event
          await db.schedule.create({
            data: {
              title: googleEvent.summary || 'Untitled Event',
              description: googleEvent.description,
              startTime: new Date(googleEvent.start.dateTime),
              endTime: new Date(googleEvent.end.dateTime),
              location: googleEvent.location,
              userId,
              googleCalendarEventId: googleEvent.id,
              aiGenerated: false
            }
          })
        }
      }
    }

    return NextResponse.json({
      message: 'Calendar sync completed successfully',
      syncResults,
      totalEvents: nexusSchedules.length,
      syncedEvents: syncResults.filter(r => r.action !== 'skipped').length
    })
  } catch (error) {
    console.error('Error syncing Google Calendar:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}