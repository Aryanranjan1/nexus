import { NextRequest, NextResponse } from 'next/server'
import { TimeZoneService } from '@/lib/services/timezone'

export async function GET() {
  try {
    const timeZones = TimeZoneService.getCommonTimeZones()
    return NextResponse.json(timeZones)
  } catch (error) {
    console.error('Error fetching time zones:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { time, fromTimeZone, toTimeZone } = data

    if (!time || !fromTimeZone || !toTimeZone) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const convertedTime = TimeZoneService.convertTime(
      new Date(time),
      fromTimeZone,
      toTimeZone
    )

    return NextResponse.json(convertedTime)
  } catch (error) {
    console.error('Error converting time:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}