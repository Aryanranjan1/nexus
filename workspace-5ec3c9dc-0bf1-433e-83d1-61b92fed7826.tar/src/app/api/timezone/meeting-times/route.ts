import { NextRequest, NextResponse } from 'next/server'
import { TimeZoneService } from '@/lib/services/timezone'

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { participants, duration, dateRange } = data

    if (!participants || !Array.isArray(participants) || participants.length === 0) {
      return NextResponse.json({ error: 'Participants are required' }, { status: 400 })
    }

    if (!duration || typeof duration !== 'number') {
      return NextResponse.json({ error: 'Duration is required' }, { status: 400 })
    }

    if (!dateRange || !dateRange.start || !dateRange.end) {
      return NextResponse.json({ error: 'Date range is required' }, { status: 400 })
    }

    const meetingTimes = TimeZoneService.findBestMeetingTime(
      participants,
      duration,
      {
        start: new Date(dateRange.start),
        end: new Date(dateRange.end)
      }
    )

    // Format the meeting times for better readability
    const formattedMeetingTimes = meetingTimes.map(slot => ({
      ...slot,
      formattedStart: TimeZoneService.formatDateTimeInTimeZone(slot.start, 'UTC'),
      formattedEnd: TimeZoneService.formatDateTimeInTimeZone(slot.end, 'UTC'),
      participantTimeZones: participants.map(p => ({
        timeZone: p.timeZone,
        localTime: {
          start: TimeZoneService.formatDateTimeInTimeZone(slot.start, p.timeZone),
          end: TimeZoneService.formatDateTimeInTimeZone(slot.end, p.timeZone)
        }
      }))
    }))

    return NextResponse.json(formattedMeetingTimes)
  } catch (error) {
    console.error('Error finding meeting times:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}