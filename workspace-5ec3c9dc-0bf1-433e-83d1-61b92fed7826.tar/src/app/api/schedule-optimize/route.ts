import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

interface SchedulingRequest {
  userId: string
  tasks: Array<{
    title: string
    description?: string
    duration: number // in minutes
    priority: 'low' | 'medium' | 'high'
    category?: string
    preferredTime?: string
    deadline?: string
    goalId?: string
  }>
  dateRange: {
    start: string
    end: string
  }
  workingHours: {
    start: string // HH:MM
    end: string // HH:MM
  }
  breakTime?: {
    duration: number // in minutes
    preferredTime?: string
  }
}

interface TimeSlot {
  start: Date
  end: Date
  available: boolean
  conflictWith?: string
}

export async function POST(request: NextRequest) {
  try {
    const data: SchedulingRequest = await request.json()
    
    // Validate input
    if (!data.userId || !data.tasks || !data.dateRange || !data.workingHours) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Get existing schedules for the date range
    const existingSchedules = await db.schedule.findMany({
      where: {
        userId: data.userId,
        startTime: {
          gte: new Date(data.dateRange.start),
          lte: new Date(data.dateRange.end)
        },
        status: { not: 'cancelled' }
      },
      orderBy: {
        startTime: 'asc'
      }
    })

    // Generate available time slots
    const availableSlots = await generateAvailableTimeSlots(
      data.dateRange,
      data.workingHours,
      existingSchedules,
      data.breakTime
    )

    // Optimize task placement
    const optimizedSchedule = await optimizeTasks(
      data.tasks,
      availableSlots,
      data.breakTime
    )

    // Create optimized schedules in database
    const createdSchedules = []
    for (const task of optimizedSchedule) {
      if (task.assignedSlot) {
        const schedule = await db.schedule.create({
          data: {
            title: task.title,
            description: task.description,
            startTime: task.assignedSlot.start,
            endTime: task.assignedSlot.end,
            priority: task.priority,
            category: task.category,
            userId: data.userId,
            goalId: task.goalId,
            aiGenerated: true
          },
          include: {
            goal: true
          }
        })
        createdSchedules.push(schedule)
      }
    }

    return NextResponse.json({
      optimizedSchedule,
      createdSchedules,
      summary: {
        totalTasks: data.tasks.length,
        scheduledTasks: createdSchedules.length,
        unscheduledTasks: data.tasks.length - createdSchedules.length,
        efficiency: calculateEfficiency(optimizedSchedule, availableSlots)
      }
    })

  } catch (error) {
    console.error('Error in schedule optimization:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

async function generateAvailableTimeSlots(
  dateRange: { start: string; end: string },
  workingHours: { start: string; end: string },
  existingSchedules: any[],
  breakTime?: { duration: number; preferredTime?: string }
): Promise<TimeSlot[]> {
  const slots: TimeSlot[] = []
  const startDate = new Date(dateRange.start)
  const endDate = new Date(dateRange.end)
  
  const [workStartHour, workStartMinute] = workingHours.start.split(':').map(Number)
  const [workEndHour, workEndMinute] = workingHours.end.split(':').map(Number)

  // Generate slots for each day in the range
  for (let date = new Date(startDate); date <= endDate; date.setDate(date.getDate() + 1)) {
    const dayStart = new Date(date)
    dayStart.setHours(workStartHour, workStartMinute, 0, 0)
    
    const dayEnd = new Date(date)
    dayEnd.setHours(workEndHour, workEndMinute, 0, 0)

    // Get existing schedules for this day
    const daySchedules = existingSchedules.filter(schedule => {
      const scheduleDate = new Date(schedule.startTime)
      return scheduleDate.toDateString() === date.toDateString()
    })

    // Sort existing schedules by start time
    daySchedules.sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())

    // Generate available slots
    let currentTime = new Date(dayStart)
    
    for (const schedule of daySchedules) {
      const scheduleStart = new Date(schedule.startTime)
      const scheduleEnd = new Date(schedule.endTime)

      // Add slot before this schedule if there's time
      if (currentTime < scheduleStart) {
        slots.push({
          start: new Date(currentTime),
          end: new Date(scheduleStart),
          available: true
        })
      }

      // Add occupied slot
      slots.push({
        start: scheduleStart,
        end: scheduleEnd,
        available: false,
        conflictWith: schedule.title
      })

      currentTime = new Date(scheduleEnd)
    }

    // Add final slot of the day
    if (currentTime < dayEnd) {
      slots.push({
        start: new Date(currentTime),
        end: new Date(dayEnd),
        available: true
      })
    }

    // Add break time if specified
    if (breakTime && breakTime.preferredTime) {
      const [breakHour, breakMinute] = breakTime.preferredTime.split(':').map(Number)
      const breakStart = new Date(date)
      breakStart.setHours(breakHour, breakMinute, 0, 0)
      
      const breakEnd = new Date(breakStart.getTime() + breakTime.duration * 60000)
      
      // Mark break time as unavailable
      const breakSlot = slots.find(slot => 
        slot.start <= breakStart && slot.end >= breakEnd
      )
      
      if (breakSlot && breakSlot.available) {
        // Split the slot and mark break time as unavailable
        const beforeBreak = {
          start: breakSlot.start,
          end: breakStart,
          available: true
        }
        
        const breakSlotObj = {
          start: breakStart,
          end: breakEnd,
          available: false,
          conflictWith: 'Break Time'
        }
        
        const afterBreak = {
          start: breakEnd,
          end: breakSlot.end,
          available: true
        }
        
        // Remove original slot and add split slots
        const slotIndex = slots.indexOf(breakSlot)
        slots.splice(slotIndex, 1, beforeBreak, breakSlotObj, afterBreak)
      }
    }
  }

  return slots
}

async function optimizeTasks(
  tasks: SchedulingRequest['tasks'],
  availableSlots: TimeSlot[],
  breakTime?: { duration: number; preferredTime?: string }
) {
  // Sort tasks by priority and deadline
  const sortedTasks = [...tasks].sort((a, b) => {
    // First by priority
    const priorityOrder = { high: 3, medium: 2, low: 1 }
    if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
      return priorityOrder[b.priority] - priorityOrder[a.priority]
    }
    
    // Then by deadline (if exists)
    if (a.deadline && b.deadline) {
      return new Date(a.deadline).getTime() - new Date(b.deadline).getTime()
    }
    
    // Finally by duration (shorter tasks first)
    return a.duration - b.duration
  })

  const optimizedTasks = sortedTasks.map(task => ({
    ...task,
    assignedSlot: null as TimeSlot | null,
    schedulingScore: 0
  }))

  // Assign tasks to available slots
  for (const task of optimizedTasks) {
    const taskDuration = task.duration * 60000 // Convert to milliseconds
    
    // Find best available slot
    let bestSlot: TimeSlot | null = null
    let bestScore = -1
    
    for (const slot of availableSlots) {
      if (!slot.available) continue
      
      const slotDuration = slot.end.getTime() - slot.start.getTime()
      
      // Check if slot can accommodate the task
      if (slotDuration >= taskDuration) {
        // Calculate scheduling score
        const score = calculateSchedulingScore(task, slot, availableSlots)
        
        if (score > bestScore) {
          bestScore = score
          bestSlot = slot
        }
      }
    }
    
    if (bestSlot) {
      task.assignedSlot = {
        start: new Date(bestSlot.start),
        end: new Date(bestSlot.start.getTime() + taskDuration)
      }
      task.schedulingScore = bestScore
      
      // Update available slots
      updateAvailableSlots(availableSlots, bestSlot, taskDuration)
    }
  }

  return optimizedTasks
}

function calculateSchedulingScore(
  task: SchedulingRequest['tasks'][0],
  slot: TimeSlot,
  availableSlots: TimeSlot[]
): number {
  let score = 0
  
  // Priority weight
  const priorityWeight = { high: 3, medium: 2, low: 1 }
  score += priorityWeight[task.priority] * 10
  
  // Time of day preference (morning slots are generally better)
  const hour = slot.start.getHours()
  if (hour >= 9 && hour <= 11) score += 5 // Morning preference
  if (hour >= 14 && hour <= 16) score += 3 // Afternoon preference
  
  // Avoid late afternoon if possible
  if (hour >= 17) score -= 3
  
  // Consider task duration vs slot size
  const slotDuration = slot.end.getTime() - slot.start.getTime()
  const taskDuration = task.duration * 60000
  const efficiency = taskDuration / slotDuration
  
  // Prefer slots that are not too tight or too loose
  if (efficiency >= 0.7 && efficiency <= 0.9) score += 3
  if (efficiency < 0.5) score -= 2
  
  // Consider deadline proximity
  if (task.deadline) {
    const deadline = new Date(task.deadline)
    const daysToDeadline = Math.ceil((deadline.getTime() - slot.start.getTime()) / (1000 * 60 * 60 * 24))
    
    if (daysToDeadline <= 1) score += 10 // Urgent
    else if (daysToDeadline <= 3) score += 5 // Soon
    else if (daysToDeadline <= 7) score += 2 // This week
  }
  
  return score
}

function updateAvailableSlots(
  availableSlots: TimeSlot[],
  usedSlot: TimeSlot,
  taskDuration: number
) {
  const slotIndex = availableSlots.indexOf(usedSlot)
  if (slotIndex === -1) return
  
  const slot = availableSlots[slotIndex]
  const taskEnd = new Date(slot.start.getTime() + taskDuration)
  
  // Split the slot into before and after the task
  if (slot.start < taskEnd) {
    const beforeSlot = {
      start: slot.start,
      end: taskEnd,
      available: false,
      conflictWith: 'Scheduled Task'
    }
    
    const afterSlot = {
      start: taskEnd,
      end: slot.end,
      available: true
    }
    
    // Replace the original slot with the split slots
    availableSlots.splice(slotIndex, 1, beforeSlot, afterSlot)
  }
}

function calculateEfficiency(
  optimizedSchedule: any[],
  availableSlots: TimeSlot[]
): number {
  const totalAvailableTime = availableSlots
    .filter(slot => slot.available)
    .reduce((total, slot) => total + (slot.end.getTime() - slot.start.getTime()), 0)
  
  const totalScheduledTime = optimizedSchedule
    .filter(task => task.assignedSlot)
    .reduce((total, task) => total + (task.duration * 60000), 0)
  
  if (totalAvailableTime === 0) return 0
  
  return Math.round((totalScheduledTime / totalAvailableTime) * 100)
}