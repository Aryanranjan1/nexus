"use client"

import { useEffect, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'

interface RealTimeEvent {
  type: 'schedule_update' | 'goal_update' | 'chat_message' | 'team_invite';
  data: any;
  userId: string;
  timestamp: Date;
}

interface UseSocketProps {
  userId?: string;
  token?: string;
}

export function useSocket({ userId, token }: UseSocketProps = {}) {
  const socketRef = useRef<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [lastEvent, setLastEvent] = useState<RealTimeEvent | null>(null)
  const [typingUsers, setTypingUsers] = useState<Map<string, boolean>>(new Map())

  useEffect(() => {
    if (!userId || !token) return

    // Initialize socket connection
    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3000', {
      auth: {
        token
      }
    })

    socketRef.current = socket

    // Connection events
    socket.on('connect', () => {
      console.log('Socket connected')
      setIsConnected(true)
      
      // Authenticate with user ID
      socket.emit('authenticate', { userId, token })
    })

    socket.on('authenticated', (data: { success: boolean; userId: string }) => {
      console.log('Socket authenticated:', data)
    })

    socket.on('disconnect', () => {
      console.log('Socket disconnected')
      setIsConnected(false)
    })

    // Real-time events
    socket.on('realtime_event', (event: RealTimeEvent) => {
      console.log('Real-time event received:', event)
      setLastEvent(event)
    })

    // Typing indicators
    socket.on('user_typing', (data: { userId: string; threadId: string; isTyping: boolean }) => {
      setTypingUsers(prev => new Map(prev).set(data.userId, data.isTyping))
    })

    // Cleanup on unmount
    return () => {
      if (socket) {
        socket.disconnect()
      }
    }
  }, [userId, token])

  // Event handlers
  const sendScheduleUpdate = (scheduleId: string, update: any) => {
    if (socketRef.current) {
      socketRef.current.emit('schedule_update', { scheduleId, update })
    }
  }

  const sendGoalUpdate = (goalId: string, update: any) => {
    if (socketRef.current) {
      socketRef.current.emit('goal_update', { goalId, update })
    }
  }

  const sendChatMessage = (threadId: string, message: string) => {
    if (socketRef.current) {
      socketRef.current.emit('chat_message', { threadId, message })
    }
  }

  const sendTeamInvite = (teamId: string, inviteeId: string, inviterId: string) => {
    if (socketRef.current) {
      socketRef.current.emit('team_invite', { teamId, inviteeId, inviterId })
    }
  }

  const joinThread = (threadId: string) => {
    if (socketRef.current) {
      socketRef.current.emit('join_thread', threadId)
    }
  }

  const leaveThread = (threadId: string) => {
    if (socketRef.current) {
      socketRef.current.emit('leave_thread', threadId)
    }
  }

  const startTyping = (threadId: string) => {
    if (socketRef.current) {
      socketRef.current.emit('typing_start', { threadId })
    }
  }

  const stopTyping = (threadId: string) => {
    if (socketRef.current) {
      socketRef.current.emit('typing_stop', { threadId })
    }
  }

  const isUserTyping = (userId: string) => {
    return typingUsers.get(userId) || false
  }

  return {
    isConnected,
    lastEvent,
    sendScheduleUpdate,
    sendGoalUpdate,
    sendChatMessage,
    sendTeamInvite,
    joinThread,
    leaveThread,
    startTyping,
    stopTyping,
    isUserTyping
  }
}